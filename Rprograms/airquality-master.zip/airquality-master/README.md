# airquality
Air Quality Dataset from UCI machine learning rep.
